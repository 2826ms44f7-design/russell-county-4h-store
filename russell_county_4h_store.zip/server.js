const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, "public");
const DATA_DIR = path.join(ROOT, "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");
const IS_PROD = process.env.NODE_ENV === "production";
const SESSION_SECRET = process.env.SESSION_SECRET || "";
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "";
const PAYMENT_MODE = (process.env.PAYMENT_MODE || "demo").toLowerCase();

if (IS_PROD && SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET must be at least 32 characters in production.");
}
if (IS_PROD && (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 16)) {
  throw new Error("Set a unique ADMIN_PASSWORD of at least 16 characters in production.");
}
if (PAYMENT_MODE !== "demo") {
  throw new Error("Only PAYMENT_MODE=demo is implemented. Add and test a real hosted checkout integration before changing this.");
}

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(ORDERS_FILE)) fs.writeFileSync(ORDERS_FILE, "[]", { mode: 0o600 });

const PRODUCTS = [
  { id: "shirt", name: "4-H Support T-Shirt", price: 20, emoji: "👕",
    description: "A comfortable fundraiser tee.", sizes: ["YS","YM","YL","S","M","L","XL","2XL"], colors: ["Kelly Green","White","Black"] },
  { id: "hoodie", name: "4-H Support Hoodie", price: 35, emoji: "🧥",
    description: "A cozy hoodie for showing support.", sizes: ["S","M","L","XL","2XL"], colors: ["Kelly Green","Gray","Black"] },
  { id: "hat", name: "4-H Support Hat", price: 18, emoji: "🧢",
    description: "A classic cap for supporters.", sizes: ["One Size"], colors: ["Kelly Green","Black"] },
  { id: "stickers", name: "4-H Sticker Pack", price: 5, emoji: "🍀",
    description: "A small way to show your 4-H pride.", sizes: ["One Size"], colors: ["Mixed"] },
  { id: "basket", name: "Community Gift Basket", price: 25, emoji: "🎁",
    description: "A sample basket idea using donated local items.", sizes: ["Standard"], colors: ["Seasonal"] }
];

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"],
      frameAncestors: ["'none'"],
      upgradeInsecureRequests: IS_PROD ? [] : null
    }
  }
}));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(session({
  name: "rc4h.sid",
  secret: SESSION_SECRET || "local-demo-only-change-this-secret-before-launch",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "strict",
    secure: IS_PROD,
    maxAge: 1000 * 60 * 60 * 4
  }
}));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false });
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: true, legacyHeaders: false,
  message: { error: "Too many login attempts. Try again later." } });
app.use("/api", apiLimiter);

function readOrders() {
  try { return JSON.parse(fs.readFileSync(ORDERS_FILE, "utf8")); }
  catch { return []; }
}
function writeOrders(orders) {
  const temp = ORDERS_FILE + "." + crypto.randomUUID() + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(orders, null, 2), { mode: 0o600 });
  fs.renameSync(temp, ORDERS_FILE);
}
function safeEqual(a, b) {
  const aa = Buffer.from(String(a || ""));
  const bb = Buffer.from(String(b || ""));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function requireCsrf(req, res, next) {
  const origin = req.get("origin");
  if (origin) {
    try {
      if (new URL(origin).host !== req.get("host")) return res.status(403).json({ error: "Origin rejected." });
    } catch { return res.status(403).json({ error: "Origin rejected." }); }
  }
  const token = req.get("x-csrf-token");
  if (!req.session.csrfToken || !safeEqual(token, req.session.csrfToken)) {
    return res.status(403).json({ error: "Session token missing or expired. Refresh the page and try again." });
  }
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.status(401).json({ error: "Please sign in as an administrator." });
  next();
}
function publicProduct(p) {
  return { id:p.id, name:p.name, price:p.price, emoji:p.emoji, description:p.description, sizes:p.sizes, colors:p.colors };
}
function dollars(n) { return Math.round(n * 100) / 100; }
function cleanString(v, max = 160) {
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}

app.get("/api/session", (req, res) => {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString("hex");
  res.json({ csrfToken: req.session.csrfToken, demoMode: true });
});
app.get("/api/products", (_req, res) => res.json(PRODUCTS.map(publicProduct)));

app.get("/api/cart", (req, res) => {
  const cart = req.session.cart || [];
  const items = cart.map(line => {
    const p = PRODUCTS.find(x => x.id === line.productId);
    if (!p) return null;
    return { ...line, name:p.name, emoji:p.emoji, unitPrice:p.price, lineTotal:p.price * line.quantity };
  }).filter(Boolean);
  res.json({ items, subtotal: dollars(items.reduce((s,x) => s+x.lineTotal, 0)) });
});

app.post("/api/cart", requireCsrf, (req, res) => {
  const product = PRODUCTS.find(p => p.id === req.body.productId);
  const quantity = Number(req.body.quantity);
  const size = cleanString(req.body.size, 20);
  const color = cleanString(req.body.color, 40);
  if (!product) return res.status(400).json({ error: "Product not found." });
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) return res.status(400).json({ error: "Quantity must be from 1 to 20." });
  if (!product.sizes.includes(size) || !product.colors.includes(color)) return res.status(400).json({ error: "Choose a valid size and color." });
  const cart = req.session.cart || [];
  const existing = cart.find(x => x.productId === product.id && x.size === size && x.color === color);
  if (existing) {
    if (existing.quantity + quantity > 20) return res.status(400).json({ error: "Maximum quantity for one variant is 20." });
    existing.quantity += quantity;
  } else {
    cart.push({ productId: product.id, size, color, quantity });
  }
  req.session.cart = cart;
  res.json({ ok:true });
});

app.patch("/api/cart", requireCsrf, (req, res) => {
  const { productId, size, color, quantity } = req.body;
  const q = Number(quantity);
  const cart = req.session.cart || [];
  const idx = cart.findIndex(x => x.productId === productId && x.size === size && x.color === color);
  if (idx < 0) return res.status(404).json({ error: "Cart item not found." });
  if (!Number.isInteger(q) || q < 0 || q > 20) return res.status(400).json({ error: "Quantity must be 0 to 20." });
  if (q === 0) cart.splice(idx, 1); else cart[idx].quantity = q;
  req.session.cart = cart;
  res.json({ ok:true });
});

app.post("/api/checkout", requireCsrf, (req, res) => {
  if (PAYMENT_MODE !== "demo") return res.status(503).json({ error: "Payments are not configured." });
  const cart = req.session.cart || [];
  if (!cart.length) return res.status(400).json({ error: "Your cart is empty." });

  const name = cleanString(req.body.name, 100);
  const email = cleanString(req.body.email, 180).toLowerCase();
  const fulfillment = cleanString(req.body.fulfillment, 20);
  const address = cleanString(req.body.address, 300);
  const notes = cleanString(req.body.notes, 500);
  if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter your name and a valid email." });
  if (!["pickup","shipping"].includes(fulfillment)) return res.status(400).json({ error: "Choose pickup or shipping." });
  if (fulfillment === "shipping" && !address) return res.status(400).json({ error: "Enter a shipping address." });

  const items = [];
  for (const line of cart) {
    const p = PRODUCTS.find(x => x.id === line.productId);
    if (!p || !p.sizes.includes(line.size) || !p.colors.includes(line.color) ||
        !Number.isInteger(line.quantity) || line.quantity < 1 || line.quantity > 20) {
      return res.status(400).json({ error: "Cart contains an invalid item. Please rebuild your cart." });
    }
    items.push({ productId:p.id, name:p.name, unitPrice:p.price, size:line.size, color:line.color,
      quantity:line.quantity, lineTotal:p.price * line.quantity });
  }
  const subtotal = dollars(items.reduce((sum,x) => sum+x.lineTotal, 0));
  const order = {
    id: "DEMO-" + crypto.randomBytes(4).toString("hex").toUpperCase(),
    createdAt: new Date().toISOString(),
    status: "DEMO — NOT PAID",
    paymentMode: "demo",
    customer: { name, email, fulfillment, address: fulfillment === "shipping" ? address : "", notes },
    items, subtotal, shipping: 0, total: subtotal,
    note: "Demo order only. No payment collected. Confirm shipping charges before accepting a real order."
  };
  const orders = readOrders();
  orders.unshift(order);
  writeOrders(orders);
  req.session.cart = [];
  res.status(201).json({ ok:true, order: { id:order.id, status:order.status, total:order.total } });
});

app.post("/api/admin/login", loginLimiter, requireCsrf, (req, res) => {
  if (!ADMIN_PASSWORD || !safeEqual(req.body.username, ADMIN_USERNAME) || !safeEqual(req.body.password, ADMIN_PASSWORD)) {
    return res.status(401).json({ error: "Invalid username or password." });
  }
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Unable to start admin session." });
    req.session.admin = true;
    req.session.csrfToken = crypto.randomBytes(32).toString("hex");
    res.json({ ok:true, csrfToken:req.session.csrfToken });
  });
});
app.get("/api/admin/me", (req, res) => res.json({ authenticated: !!req.session.admin }));
app.post("/api/admin/logout", requireAdmin, requireCsrf, (req, res) => {
  req.session.destroy(() => res.json({ ok:true }));
});
app.get("/api/admin/orders", requireAdmin, (_req, res) => {
  const orders = readOrders().map(o => ({ ...o, customer: { ...o.customer, address: o.customer.fulfillment === "shipping" ? o.customer.address : "" } }));
  res.json({ orders });
});
app.patch("/api/admin/orders/:id", requireAdmin, requireCsrf, (req, res) => {
  const allowed = ["DEMO — NOT PAID", "Cancelled", "Fulfilled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid status." });
  const orders = readOrders();
  const order = orders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  // Demo mode deliberately does not allow any order to be marked paid.
  order.status = req.body.status;
  order.updatedAt = new Date().toISOString();
  writeOrders(orders);
  res.json({ ok:true });
});
app.get("/api/admin/dashboard", requireAdmin, (_req, res) => {
  const orders = readOrders();
  const demoTotal = orders.filter(o => o.status !== "Cancelled").reduce((s,o) => s + Number(o.total || 0), 0);
  res.json({
    totalOrders: orders.length,
    openOrders: orders.filter(o => o.status === "DEMO — NOT PAID").length,
    cancelledOrders: orders.filter(o => o.status === "Cancelled").length,
    demoOrderValue: dollars(demoTotal),
    goal: 5000,
    mode: "DEMO — values are not verified donations or money received"
  });
});

app.use(express.static(PUBLIC, { extensions: ["html"] }));
app.get("*", (req, res) => res.sendFile(path.join(PUBLIC, "index.html")));
app.use((err, _req, res, _next) => {
  console.error("Request error:", err.message);
  res.status(500).json({ error: "An unexpected server error occurred." });
});

app.listen(PORT, () => console.log(`4-H demo store running at http://localhost:${PORT}`));
