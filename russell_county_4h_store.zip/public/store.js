let csrfToken = "";
let products = [];
const $ = (id) => document.getElementById(id);
const money = (n) => new Intl.NumberFormat("en-US", {style:"currency",currency:"USD"}).format(n);
async function api(url, options={}) {
  const headers = {...(options.headers||{})};
  if (options.body && !(options.body instanceof FormData)) headers["Content-Type"] = "application/json";
  if (options.method && options.method !== "GET") headers["X-CSRF-Token"] = csrfToken;
  const response = await fetch(url, {...options, headers, credentials:"same-origin"});
  const data = await response.json().catch(()=>({error:"Unexpected server response."}));
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}
function toast(message) {
  const el=$("toast"); el.textContent=message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),2600);
}
async function init() {
  const session = await api("/api/session");
  csrfToken = session.csrfToken;
  products = await api("/api/products");
  renderProducts();
  await refreshCart();
  await refreshDashboard();
  $("year").textContent = new Date().getFullYear();
}
function renderProducts() {
  $("products").replaceChildren();
  for (const p of products) {
    const card=document.createElement("article"); card.className="product-card";
    const art=document.createElement("div"); art.className="product-art"; art.textContent=p.emoji;
    const info=document.createElement("div"); info.className="product-info";
    const title=document.createElement("h3"); title.textContent=p.name;
    const desc=document.createElement("p"); desc.textContent=p.description;
    const price=document.createElement("div"); price.className="price"; price.textContent=money(p.price);
    const options=document.createElement("div"); options.className="product-options";
    const sizeLabel=document.createElement("label"); sizeLabel.textContent="Size";
    const size=document.createElement("select"); size.setAttribute("aria-label",p.name+" size");
    p.sizes.forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;size.append(o);});
    sizeLabel.append(size);
    const colorLabel=document.createElement("label"); colorLabel.textContent="Color";
    const color=document.createElement("select"); color.setAttribute("aria-label",p.name+" color");
    p.colors.forEach(v=>{const o=document.createElement("option");o.value=v;o.textContent=v;color.append(o);});
    colorLabel.append(color);
    const qLabel=document.createElement("label");qLabel.className="quantity";qLabel.textContent="Quantity";
    const q=document.createElement("input");q.type="number";q.min="1";q.max="20";q.value="1";q.setAttribute("aria-label",p.name+" quantity");qLabel.append(q);
    options.append(sizeLabel,colorLabel,qLabel);
    const button=document.createElement("button");button.className="button button-green";button.textContent="Add to cart";
    button.addEventListener("click",async()=>{
      try {
        await api("/api/cart",{method:"POST",body:JSON.stringify({productId:p.id,size:size.value,color:color.value,quantity:Number(q.value)})});
        await refreshCart();toast("Added to your cart.");
      } catch(e){toast(e.message);}
    });
    info.append(title,desc,price,options,button);card.append(art,info);$("products").append(card);
  }
}
async function refreshCart() {
  const cart=await api("/api/cart");
  $("cartCount").textContent=cart.items.reduce((s,x)=>s+x.quantity,0);
  $("cartSubtotal").textContent=money(cart.subtotal);
  const target=$("cartItems");target.replaceChildren();
  if(!cart.items.length){const p=document.createElement("p");p.className="muted";p.textContent="Your cart is empty.";target.append(p);}
  cart.items.forEach(item=>{
    const row=document.createElement("div");row.className="cart-line";
    const left=document.createElement("div");const title=document.createElement("strong");title.textContent=item.emoji+" "+item.name;
    const details=document.createElement("small");details.textContent=`${item.size} · ${item.color} · ${money(item.unitPrice)} each`;
    const actions=document.createElement("div");actions.className="cart-actions";
    const minus=document.createElement("button");minus.textContent="−";minus.setAttribute("aria-label","Decrease quantity");
    const qty=document.createElement("span");qty.textContent=item.quantity;
    const plus=document.createElement("button");plus.textContent="+";plus.setAttribute("aria-label","Increase quantity");
    const remove=document.createElement("button");remove.textContent="Remove";
    const change=async(n)=>{try{await api("/api/cart",{method:"PATCH",body:JSON.stringify({productId:item.productId,size:item.size,color:item.color,quantity:n})});await refreshCart();}catch(e){toast(e.message);}};
    minus.onclick=()=>change(item.quantity-1);plus.onclick=()=>change(item.quantity+1);remove.onclick=()=>change(0);
    actions.append(minus,qty,plus,remove);left.append(title,details,actions);
    const lineTotal=document.createElement("strong");lineTotal.textContent=money(item.lineTotal);
    row.append(left,lineTotal);target.append(row);
  });
}
async function refreshDashboard() {
  try {
    const d=await api("/api/admin/dashboard");
    $("raised").textContent=money(d.demoOrderValue);
    $("progress").style.width=Math.min(100,d.demoOrderValue/d.goal*100)+"%";
    $("goalNote").textContent=d.mode;
  } catch { $("goalNote").textContent="Dashboard totals are currently unavailable."; }
}
$("openCart").onclick=async()=>{await refreshCart();$("cartDialog").showModal();};
$("closeCart").onclick=()=>$("cartDialog").close();
$("closeCheckout").onclick=()=>$("checkoutDialog").close();
$("goCheckout").onclick=async()=>{
  const c=await api("/api/cart");
  if(!c.items.length){$("cartMessage").textContent="Add an item before checkout.";return;}
  $("cartDialog").close();$("checkoutDialog").showModal();
};
$("fulfillment").addEventListener("change",()=>{
  const shipping=$("fulfillment").value==="shipping";
  $("addressLabel").hidden=!shipping;
  $("checkoutForm").elements.address.required=shipping;
});
$("checkoutForm").addEventListener("submit",async(e)=>{
  e.preventDefault();$("checkoutMessage").textContent="Creating demo order…";
  const f=new FormData(e.currentTarget);
  const body=Object.fromEntries(f.entries());
  try{
    const result=await api("/api/checkout",{method:"POST",body:JSON.stringify(body)});
    $("checkoutDialog").close();
    $("successText").textContent=`Order ${result.order.id} was created for ${money(result.order.total)}. Status: ${result.order.status}. No payment was collected.`;
    $("successDialog").showModal();e.currentTarget.reset();$("addressLabel").hidden=true;
    await refreshCart();await refreshDashboard();
  }catch(err){$("checkoutMessage").textContent=err.message;}
});
$("finishOrder").onclick=()=>$("successDialog").close();
init().catch(err=>{console.error(err);$("products").textContent="Unable to load the store. Make sure the server is running.";});
