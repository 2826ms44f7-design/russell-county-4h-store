let csrfToken="";
const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n);
async function api(url,options={}){
 const headers={...(options.headers||{})};
 if(options.body)headers["Content-Type"]="application/json";
 if(options.method&&options.method!=="GET")headers["X-CSRF-Token"]=csrfToken;
 const r=await fetch(url,{...options,headers,credentials:"same-origin"});
 const d=await r.json().catch(()=>({error:"Unexpected response"}));
 if(!r.ok)throw new Error(d.error||"Request failed");return d;
}
async function getSession(){const s=await api("/api/session");csrfToken=s.csrfToken;}
async function checkAuth(){
 const m=await api("/api/admin/me");
 $("loginPanel").hidden=m.authenticated;
 $("dashboardPanel").hidden=!m.authenticated;
 $("logout").hidden=!m.authenticated;
 if(m.authenticated)await loadDashboard();
}
$("loginForm").addEventListener("submit",async e=>{
 e.preventDefault();$("loginMessage").textContent="Signing in…";
 const f=new FormData(e.currentTarget);
 try{
  const result=await api("/api/admin/login",{method:"POST",body:JSON.stringify(Object.fromEntries(f.entries()))});
  csrfToken=result.csrfToken;e.currentTarget.reset();$("loginMessage").textContent="";
  await checkAuth();
 }catch(err){$("loginMessage").textContent=err.message;}
});
$("logout").onclick=async()=>{
 try{await api("/api/admin/logout",{method:"POST",body:JSON.stringify({})});await getSession();await checkAuth();}
 catch(err){alert(err.message);}
};
$("refreshOrders").onclick=()=>loadDashboard();
async function loadDashboard(){
 try{
  const [d,o]=await Promise.all([api("/api/admin/dashboard"),api("/api/admin/orders")]);
  $("totalOrders").textContent=d.totalOrders;$("openOrders").textContent=d.openOrders;$("demoValue").textContent=money(d.demoOrderValue);
  renderOrders(o.orders);
 }catch(err){$("ordersMessage").textContent=err.message;}
}
function renderOrders(orders){
 const body=$("ordersBody");body.replaceChildren();
 if(!orders.length){const tr=document.createElement("tr"),td=document.createElement("td");td.colSpan=6;td.textContent="No orders yet.";tr.append(td);body.append(tr);return;}
 orders.forEach(o=>{
  const tr=document.createElement("tr");
  const td=(text,cls)=>{const el=document.createElement("td");if(cls)el.className=cls;el.textContent=text;tr.append(el);return el;};
  td(o.id);const customer=td(o.customer.name+"\n"+o.customer.email);customer.style.whiteSpace="pre-line";
  const items=td("","order-items");
  o.items.forEach(i=>{const line=document.createElement("div");line.textContent=`${i.quantity} × ${i.name}`;const small=document.createElement("small");small.textContent=`${i.size} · ${i.color}`;line.append(small);items.append(line);});
  td(money(o.total));
  const status=td(o.status);const pill=document.createElement("span");pill.className="status-pill"+(o.status==="Fulfilled"?" fulfilled":o.status==="Cancelled"?" cancelled":"");pill.textContent=o.status;status.replaceChildren(pill);
  const manage=td("");const select=document.createElement("select");["DEMO — NOT PAID","Fulfilled","Cancelled"].forEach(s=>{const op=document.createElement("option");op.value=s;op.textContent=s;select.append(op);});select.value=o.status;
  const save=document.createElement("button");save.className="button button-green";save.style.padding="7px 10px";save.style.marginTop="7px";save.textContent="Save";
  save.onclick=async()=>{try{await api("/api/admin/orders/"+encodeURIComponent(o.id),{method:"PATCH",body:JSON.stringify({status:select.value})});$("ordersMessage").textContent="Order updated.";await loadDashboard();}catch(e){$("ordersMessage").textContent=e.message;}};
  manage.append(select,document.createElement("br"),save);body.append(tr);
 });
}
(async()=>{try{await getSession();await checkAuth();}catch(e){$("loginMessage").textContent=e.message;}})();
