# Russell County 4-H Fundraising Store

A demo-first, full-stack online fundraising store built with Node.js, Express, and plain HTML/CSS/JavaScript.

## Included
- Product catalog with sizes and colors
- Cart stored in the server-side session
- Demo checkout for **local pickup or shipping**
- Server-side price validation (browser prices are never trusted)
- Order records saved locally to `data/orders.json`
- Admin login, order management, and dashboard
- Fundraising totals based on demo orders, clearly labeled as demo
- Basic security headers, rate limits, session cookies, and same-origin checks

## Important before launch
This project starts in **DEMO CHECKOUT** mode. It does not collect payment information or charge cards. Demo orders are marked `DEMO — NOT PAID` and must not be treated as paid orders or tax-deductible donations.

For real payments, connect a supported provider using its official server-side SDK and hosted checkout flow. Do not collect or store card numbers in this app. You will also need:
1. Approval to use Russell County 4-H's name and any official 4-H logos.
2. Approval from the 4-H agent/organization for the products, fundraising claims, and recipient of funds.
3. A production database instead of the included JSON-file storage.
4. HTTPS, secure environment variables, backups, logging, and deployment hardening.
5. Verified shipping rates, pickup instructions, refund/cancellation policy, privacy policy, and sales-tax settings.
6. Review of Virginia and local rules for sales, donations, and any raffles. This app does not implement raffle sales.
7. A payment provider's webhook verification before orders are marked paid.

## Run locally
Install Node.js 20 or newer, then:

```bash
cp .env.example .env
```

Edit `.env` and set a unique `SESSION_SECRET` and `ADMIN_PASSWORD`. Then:

```bash
npm install
npm start
```

Open `http://localhost:3000`.

Admin: `http://localhost:3000/admin.html`

Use the credentials in `.env`. Never publish `.env` or commit it to source control.

## Data
Orders are saved in `data/orders.json`, created automatically. This is suitable only for a local demo or low-risk prototype. Do not use JSON-file storage for a live multi-user store.

## Payment integration
`server.js` deliberately rejects non-demo payment modes until a real provider integration is implemented. Do not simply change `PAYMENT_MODE` to `live`; add hosted checkout session creation, signed webhook verification, idempotency, order reconciliation, and provider-specific tests first.

## Demo behavior
- Customers can add products, choose variants, select shipping/pickup, and submit a demo order.
- No real money changes hands.
- The dashboard labels amounts as demo order value, not verified donations or actual funds raised.
